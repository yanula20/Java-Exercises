
/* This lab prints my initials as I practice
 * using System.out.println and System.out.print 
 * statements.*/

//This is Don Moore's first lab

public class Initials {
  public static void main(String[] args) {
    System.out.println("Lab 0 written by DONALD_ANDRE_MOORE");
    System.out.println();
    System.out.println("D D                A             M         M");
    System.out.println("D   D            A   A           M M     M M");
    System.out.println("D    D          A     A          M   M M   M");
    System.out.println("D     D        A A A A A         M    M    M");
    System.out.println("D     D       A         A        M         M");
    System.out.println("D    D       A           A       M         M");
    System.out.println("D   D       A             A      M         M");
    System.out.println("D D        A               A     M         M");
    System.out.println();
    System.out.println("This lab provides practice\n using print line statements\n to display my initials."); 
  }
}